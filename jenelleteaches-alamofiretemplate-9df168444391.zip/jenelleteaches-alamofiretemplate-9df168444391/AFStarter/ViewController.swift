//
//  ViewController.swift
//  AFStarter
//
//  Created by parrot on 2018-11-13.
//  Copyright © 2018 room1. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON


class ViewController: UIViewController {

    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var lblHumidity: UILabel!
    @IBOutlet weak var lblRain: UILabel!
    @IBOutlet weak var lblWind: UILabel!
    @IBOutlet weak var lblMsg: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func weatherbtn(_ sender: Any) {
        print("weather button pressed")
        
        // go to the url
        let URL = "https://api.darksky.net/forecast/8b0eb93c606b823b236c741aa6c69c1f/43.6532,-79.3832?units=ca"
        
        // get data from the website
        Alamofire.request(URL, method: .get, parameters: nil).responseJSON {
        (response) in
            
            if(response.result.isSuccess){
                print("i get something from the weather website")
                print("Response from the website")
                print("=====")
                print(response.data)
                
                do{
                    let json = try JSON(data: response.data!)
                    print("here is data====")
                    //print(json)
                    // write the code to print lat, long, and temprature
                    print(json["latitude"])
                    print(json["longitude"])
                    print(json["currently"]["temperature"])
                    print(json["currently"]["time"])
                   // if  let  timeResult = (jsonResult["dt"] as? Double) {
                        let date = Date(timeIntervalSince1970: 1542381864)
                        let dateFormatter = DateFormatter()
                        dateFormatter.timeStyle = DateFormatter.Style.medium //Set time style
                        dateFormatter.dateStyle = DateFormatter.Style.medium //Set date style
                        let localDate = dateFormatter.string(from: date)
                        print(localDate)
                   // self.lblTime.text = "\(json["currently"]["time"])"
                   self.lblTime.text = localDate
                    self.lblTemp.text = "\(json["currently"]["temperature"])°C"
                    self.lblHumidity.text = "\(json["currently"]["humidity"])%"
                    self.lblRain.text = "\(json["currently"]["precipProbability"])%"
                    self.lblWind.text = "\(json["currently"]["windSpeed"])KM Per Hour"
                    self.lblMsg.text = "\(json["currently"]["summary"])"
                }catch{
                    print("error parsing data")
                }
            }
        
        else{
            print("error getting data from website")
        }
        //parse the data you need
        
        //do something with data
    }
    
}

}
